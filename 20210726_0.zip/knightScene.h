#pragma once
class knightScene
{
public:
	knightScene();
	~knightScene();
};

