#include "pch.h"
#include "knightScene.h"


knightScene::knightScene()
{
}


knightScene::~knightScene()
{
}
